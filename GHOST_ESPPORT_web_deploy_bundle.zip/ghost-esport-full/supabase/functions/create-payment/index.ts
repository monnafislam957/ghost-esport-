// Payment integration scaffold. Deliberately fails closed until a merchant
// provider integration has been completed and reviewed.
// Deploy with Supabase CLI only after implementing official provider API calls.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

Deno.serve(async (req) => {
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405 });
  const url = Deno.env.get("SUPABASE_URL");
  const anon = Deno.env.get("SUPABASE_ANON_KEY");
  const service = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  if (!url || !anon || !service) return Response.json({ error: "Server configuration missing" }, { status: 500 });

  const authHeader = req.headers.get("Authorization");
  if (!authHeader) return Response.json({ error: "Authentication required" }, { status: 401 });
  const userClient = createClient(url, anon, { global: { headers: { Authorization: authHeader } } });
  const { data: { user }, error: authError } = await userClient.auth.getUser();
  if (authError || !user) return Response.json({ error: "Invalid session" }, { status: 401 });

  // Do not create a fake checkout or accept client-provided amounts/provider status.
  // Implement official bKash/Nagad merchant checkout here, server-side, with:
  // 1) match/registration ownership and fee checks from database;
  // 2) amount calculated from trusted database rows, not request JSON;
  // 3) idempotency key and server-only merchant credentials;
  // 4) provider signature / callback verification before marking a payment paid;
  // 5) persisted provider transaction ID and audit log.
  // This starter intentionally returns 501 so no real payment can accidentally run.
  return Response.json({
    error: "Payments are disabled. Configure and test an approved bKash/Nagad merchant integration before enabling checkout."
  }, { status: 501 });
});